import nltk
from nltk.stem import WordNetLemmatizer
import json
import pickle
import random
import numpy as np
from keras.models import Sequential
from keras.layers import Dense, Activation, Dropout
from keras.optimizers import Adam
from sklearn.model_selection import train_test_split

lemmatizer = WordNetLemmatizer()

# Load JSON file and access the 'intents' key
data_file = open('data.json').read()
intents = json.loads(data_file)['intents']

words = []
classes = []
documents = []
ignore_words = ['?']

for intent in intents:
    question = intent['question']
    answer = intent['answer']

    # Tokenize words in both question and answer
    question_words = nltk.word_tokenize(question)
    answer_words = nltk.word_tokenize(answer)

    # Lemmatize and add to words list
    words.extend([lemmatizer.lemmatize(word.lower()) for word in question_words])
    words.extend([lemmatizer.lemmatize(word.lower()) for word in answer_words])

    # Add documents to the corpus
    documents.append((question_words, intent['tags']))
    documents.append((answer_words, intent['tags']))

    # Append tags directly to classes
    classes.extend(intent['tags'])

# Lemmatize and remove duplicates
words = sorted(list(set([lemmatizer.lemmatize(word.lower()) for word in words])))

# Sort classes
classes = sorted(list(set(classes)))

pickle.dump(words, open('texts.pkl', 'wb'))
pickle.dump(classes, open('labels.pkl', 'wb'))

# Create training data
training = []
output_empty = [0] * len(classes)

for doc in documents:
    bag = []
    pattern_words = doc[0]
    pattern_words = [lemmatizer.lemmatize(word.lower()) for word in pattern_words]

    # Create our bag of words array with 1, if word match found in current pattern
    for w in words:
        bag.append(1) if w in pattern_words else bag.append(0)

    # Output is a '0' for each tag and '1' for current tag (for each pattern)
    output_row = list(output_empty)
    for tag in doc[1]:
        output_row[classes.index(tag)] = 1

    training.append([bag, output_row])

random.shuffle(training)

train_x = np.array([i[0] for i in training])
train_y = np.array([j[1] for j in training])

# Split the data into training and testing sets
train_x, test_x, train_y, test_y = train_test_split(train_x, train_y, test_size=0.2, random_state=42)
from keras.callbacks import EarlyStopping
# Define and compile your model
model = Sequential()
model.add(Dense(256, input_shape=(len(train_x[0]),), activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(128, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(len(train_y[0]), activation='sigmoid'))

# Use Adam optimizer for better convergence
adam = Adam(learning_rate=0.001)
model.compile(loss='binary_crossentropy', optimizer=adam, metrics=['accuracy'])

# Implement early stopping
early_stopping = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)

# Train your model
hist = model.fit(train_x, train_y, epochs=50, batch_size=10, validation_data=(test_x, test_y), callbacks=[early_stopping], verbose=1)

# Evaluate the model on the test set
loss, accuracy = model.evaluate(test_x, test_y)
print(f'Test Loss: {loss:.4f}, Test Accuracy: {accuracy * 100:.2f}%')

# Save your model
model.save('model.h5')
